var initializeMenu = function () {
        var $menu = $(".main-menu");

        $("a.menu-item.containers", $menu).mouseover(function () {
            $(".submenu-right.containers").show();
        });

        $("a.menu-item.containers", $menu).mouseleave(function () {
            if ($(".submenu-right.containers:hover").length == 0)
                $(".submenu-right.containers").hide();
        });

        $(".submenu-right.containers").mouseleave(function () {
            $(".submenu-right.containers").hide();
        });
    
        $(".submenu-right.containers").mouseover(function () {
            $(".submenu-right.containers").show();
        });

        $("a.menu-item.endpoint", $menu).click(function () {
            $(".submenu-down.endpoint").slideToggle(200);
            $(this).toggleClass("open").toggleClass("active");
        });
    },
    
    /* Initialize editor items in header */
    initializeEditors = function () {
        var $editor = $(".editor", $("header")),
            editors = theJSON.messageFlowEditor.editors;
        for (var i in editors) {
            var editor = editors[i],
                $editorItem = $('<a class="editor-item ' + editor.class + '" href="javascript:;"></a>');
            $editorItem.append($('<div class="icon"></div>'));
            $editorItem.append(editor.name);
            if (editor.active) {
                $editorItem.addClass("active");
            } else {
                $editorItem.addClass("inactive");
            }
            $editor.append($editorItem);
        }
    },
    
    /* Initialize the issue counters */
    initializeTitleBar = function() {
        var $titleBar = $(".title-bar", $("header")),
            $openIssues = $(".open-issues", $titleBar),
            $openIssuesIndicator = $(".number-indicator", $openIssues),
            $closedIssues = $(".closed-issues", $titleBar),
            $closedIssuesIndicator = $(".number-indicator", $closedIssues),
            openCounter = theJSON.messageFlowEditor.issues.open,
            closedCounter = theJSON.messageFlowEditor.issues.closed;
        
        /* Set the issues counter, if > 99 then set to "99+"*/
        $("p", $openIssuesIndicator).html(openCounter < 99 ? openCounter : "99+");
        $("p", $closedIssuesIndicator).html(closedCounter < 99 ? closedCounter : "99+");
    };

/* Document ready function, after JSON data is loaded */
$("html").bind("JSONLoaded", function () {
    initializeMenu();
    initializeEditors();
    initializeTitleBar();
    $("h1.title", $("header")).html(theJSON.messageFlowName);
    $(".content").perfectScrollbar();
})

/* The JSON object, to be used in the document js */
var theJSON;

$(function () {
    $.getJSON("/js/json/message-flow-designer.json")
        .done(function (data) {
            theJSON = data;
            /* Fire an "JSONLoaded" event, indicating that JSON Object is loaded into the javascript runtime, to be caught by the document js */
            $("html").trigger("JSONLoaded");
        })
        .fail(function (data) {
            alert("Warning: JSON load failure.");
            console.log(data);
        });
});