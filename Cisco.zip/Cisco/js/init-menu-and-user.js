    /* Initialize the menu items in the left sidebar */
var initializeMenuItems = function () {
        var mainMenuItems = theJSON.menus.mainMenu,
            slaveMenus = theJSON.menus.slaveMenu;
        for (var i in mainMenuItems) {
            var mainMenuItem = mainMenuItems[i],
                htmlStr = '<a class="menu-item ' + mainMenuItem.iconClass + '" href="' + mainMenuItem.href + '">' +
                mainMenuItem.name;
            if (mainMenuItem.hasNumberIndicator) {
                htmlStr +=
                    '<div class="number-indicator ' + mainMenuItem.numberIndicatorClass + '">' +
                    '<p>' + (mainMenuItem.numberIndicator < 99 ? mainMenuItem.numberIndicator : "99+") + '</p>' +
                    '</div>';
            }
            htmlStr += '</a>';
            $(".main-menu", $(".left-sidebar")).append($(htmlStr));
        }
        for (var i in slaveMenus) {
            var slaveMenu = slaveMenus[i],
                slaveMenuTitle = slaveMenu.title,
                slaveMenuItems = slaveMenu.menuItems,
                $slaveMenu = $('<div class="slave-menu"></div>');
            $slaveMenu.append($('<div class="menu-title">' + slaveMenuTitle + '</div>'));

            for (var j in slaveMenuItems) {
                var slaveMenuItem = slaveMenuItems[i];
                $slaveMenu.append($('<a class="menu-item ' + slaveMenuItem.iconClass + '" href="' + slaveMenuItem.href + '">' +
                    slaveMenuItem.name +
                    '</a>'));
            }
            $(".left-sidebar").append($slaveMenu);
            console.log($slaveMenu);
        }
    },
    
    /* initialize User Panel */
    initializeUserPanel = function() {
        var user = theJSON.user,
            username = user.username,
            avatar = user.avatar,
            $userPanel = $(".user-panel", $("header"));
        $("img.user-avatar", $userPanel).attr("src", user.avatar);
        $("span", $("a.user", $userPanel)).append(username);
    };