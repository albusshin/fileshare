"use strict";

    /* The line chart showing */
var lineChart = null,
    /* The pie chart showing */
    pieChart = null,
    /* The bar chart showing */
    barChart = null,
    /* The active chart set */
    activeTabNum = 0,
    scrollbarViewAllActivities = null,
    scrollbarSortByPriority = null,
    /* Draw a pie chart, specifying with or without animation*/
    drawPieChart = function(activeChartNum, withAnimation) {
        var ctx = $("#pie-chart-canvas").get(0).getContext("2d"),
            pieChartJSON = theJSON.charts.pieCharts.charts[activeChartNum],
            pieChartData = pieChartJSON.data,
            pieChartOptions = pieChartJSON.options;
        
        pieChartOptions.animation = withAnimation;
        pieChart = new Chart(ctx).Doughnut(pieChartData, pieChartOptions);
    },
    /* Draw a pie chart with animation */
    initializePieChart = function (activeChartNum) {
        var pieChartTitle = theJSON.charts.pieCharts.title,
            pieChartJSON = theJSON.charts.pieCharts.charts[activeChartNum],
            pieChartData = pieChartJSON.data,
            percentage = pieChartData[0].value / (pieChartData[0].value + pieChartData[1].value) * 100;
        drawPieChart(activeChartNum, true);
        $("h2.title", $(".pie-chart-area")).html(pieChartTitle);
        $(".percentage-indicator", $(".pie-chart-inside")).html(percentage + "%");
        $(".title", $(".pie-chart-inside")).html(pieChartJSON.chartInside.title);
        $(".number", $(".pie-chart-outside")).html(pieChartJSON.chartOutside.number);
        $(".icon", $(".change", $(".pie-chart-outside"))).removeClass("growth")
        .removeClass("decrease")
        .addClass(pieChartJSON.chartOutside.change);
        $("span", $(".change", $(".pie-chart-outside"))).html(pieChartJSON.chartOutside.percentage + "%");
        $(".title", $(".pie-chart-outside")).html(pieChartJSON.chartOutside.title);
    },

    /* Draw a bar chart, specifying with or without animation */
    drawBarChart = function (activeChartNum, withAnimation) {
        var ctx = $("#bar-chart-canvas").get(0).getContext("2d"),
            barChartData = theJSON.charts.barCharts.charts[activeChartNum].data,
            barChartOptions = theJSON.charts.barCharts.charts[activeChartNum].options;
        barChartOptions.animation = withAnimation;
        barChart = new Chart(ctx).StackedBar(barChartData, barChartOptions);
    },

    /* Draw a bar chart with animation */
    initializeBarChart = function (activeChartNum) {
        drawBarChart(activeChartNum, true);
        $("h2.title", $(".bar-chart-area")).html(theJSON.charts.barCharts.title);
    },

    /* Draw Metric tabs*/
    drawMetricTabs = function () {
        var tabs = theJSON.charts.tabs;
        for (var i in tabs) {
            var tab = tabs[i],
                $tab = $('<a class="tab" href="javascript:;" data-index="' + i + '">' + tab + '</a>');
            if (i == "0") $tab.addClass("active");
            $(".tabs").append($tab);
        }
    },

    /* Draw a line chart without legends or labels */
    drawLineChart = function (activeChartNum, withAnimation) {
        var ctx = $("#line-chart-canvas").get(0).getContext("2d"),
            lineChartData = theJSON.charts.lineCharts.charts[activeChartNum].data,
            lineChartOptions = theJSON.charts.lineCharts.charts[activeChartNum].options,
            lineChartLabels = theJSON.charts.lineCharts.charts[activeChartNum].labels;
        $("h2.title", $(".line-chart-area")).html(theJSON.charts.lineCharts.title);
        if (lineChart !== null) lineChart.clear();
        lineChartOptions.animation = withAnimation;
        lineChart = new Chart(ctx).Line(lineChartData, lineChartOptions);
    },

    /* Draw a line chart with animation, legends and labels */
    initializeLineChart = function (activeChartNum) {
        drawLineChart(activeChartNum, true);
        var lineChartData = theJSON.charts.lineCharts.charts[activeChartNum].data,
            lineChartOptions = theJSON.charts.lineCharts.charts[activeChartNum].options,
            lineChartLabels = theJSON.charts.lineCharts.charts[activeChartNum].labels,
            /* Show legends */
            $legends = $(".legends", $(".line-chart.active")).empty(),
            lineChartDatasets = lineChartData.datasets;
        $legends.append($('<a class="line-chart-add" href="javascript:;">+Add</a>'));
        for (var i in lineChartDatasets) {
            var $legend = $('<div class="legend"><div class="color"></div>' +
                    lineChartDatasets[i].label +
                    '</div>')
                .addClass(i + "");
            $("div.color", $legend).css("background-color", lineChartDatasets[i].strokeColor);
            $legends.append($legend);
        }

        /* Set line chart labels */
        var $chartLabels = $(".chart-labels", $(".line-chart.active")).empty();
        for (var i in lineChartLabels) {
            var $chartLabel = $('<div class="chart-label ' + i + '">' +
                lineChartLabels[i] +
                '</div>');
            $chartLabels.append($chartLabel);
        }

        $(".chart-label", $chartLabels).css("width", 100 / lineChartLabels.length + "%");
    },

    /* Initialize all the charts */
    initializeCharts = function () {
        /* set canvas size */
        $("#line-chart-canvas").width($(".line-chart-area", $(".content")).width() - 38).height(170);
        $("#bar-chart-canvas").width($(".bar-chart-area", $(".content")).width() - 20).height(190);

        /* set line chart tabs onclick handler */
        $(".tab", $(".tabs", $(".line-chart-area"))).click(function (event) {
            $(this).siblings().removeClass("active");
            $(this).addClass("active");
            var i = $(this).data("index");
            initializeLineChart(i);
            initializeBarChart(i);
            initializePieChart(i);
            activeTabNum = i;
        });
        initializePieChart(0);
        initializeBarChart(0);
        initializeLineChart(0);
    },

    closeAccordionPanel = function ($accordionPanel) {
        $("a.title", $accordionPanel).addClass("closed");
        $(".accordion-content", $accordionPanel).slideUp(200).removeClass("active");

        $($accordionPanel).removeClass("open");
        $(".scrollable", $accordionPanel).animate({
            height: 0
        }, 200);
    },

    openAccordionPanel = function ($accordionPanel) {
        $("a.title", $accordionPanel).removeClass("closed");
        $(".accordion-content", $accordionPanel)
            .slideDown(200)
            .addClass("active");
        $($accordionPanel).addClass("open");
        $(".scrollable", $accordionPanel).height(window.innerHeight - 29 * 3 - 71).perfectScrollbar();
    },

    /* Append activities to accordion content area */
    appendActivitiesToAccordionContent = function (activities, $accordionContent) {
        for (var i in activities) {
            var activity = activities[i],
                $activityItem = $('<a class="activity-item ' + activity.type + '-item" href="javascript:;">' +
                    '<div class="icon"></div>' +
                    '<h3 class="title">' +
                    activity.title +
                    '</h3>' +
                    '<p class="details">' +
                    activity.details +
                    '</p>' +
                    '<div class="datetime">' +
                    activity.datetime +
                    '</div>' +
                    '</a>');
            $accordionContent.append($activityItem);
        }
    },

    /* Initialize the activities on the right sidebar */
    initializeActivities = function () {
        var $activity = $(".activity", $(".right-sidebar")),
            $viewAllActivities = $(".view-all-activities", $activity),
            $sortByPriority = $(".sort-by-priority", $activity),
            activities = theJSON.activities,
            activityTypes = theJSON.activityTypes;
        /* first append all the activities to "view-all-activities" accordion content area */
        appendActivitiesToAccordionContent(activities, $(".accordion-content", $viewAllActivities));
        /* sort the array by priority */
        activities.sort(function (a, b) {
            if (a.priority > b.priority) return -1;
            else if (a.priority == b.priority) return 0;
            else return 1;
        });
        /* then append the sorted activities to "sort-by-priority" accordion content area */
        appendActivitiesToAccordionContent(activities, $(".accordion-content", $sortByPriority));

        $("a.title", $viewAllActivities).click(function (event) {
            if ($(this).hasClass("closed")) {
                closeAccordionPanel($sortByPriority);
                openAccordionPanel($viewAllActivities);
            } else {
                closeAccordionPanel($viewAllActivities);
            }
        });
        $("a.title", $sortByPriority).click(function (event) {
            if ($(this).hasClass("closed")) {
                closeAccordionPanel($viewAllActivities);
                openAccordionPanel($sortByPriority);
            } else {
                closeAccordionPanel($sortByPriority);
            }
        });
        $("span", $("a.title", $(".view-all-activities"))).html(activityTypes[0]);
        $("span", $("a.title", $(".sort-by-priority"))).html(activityTypes[1]);
    },

    initializeOverviewPanel = function () {
        var $overviewPanel = $(".overview-panel", $(".content")),
            $firstRow = $(".first-row", $overviewPanel),
            $secondRow = $(".second-row", $overviewPanel),
            rows = [$firstRow, $secondRow],
            overviewContent = theJSON.overview,
            appendToRow = function (i, $row) {

                var item = overviewContent[i],
                    $item = $('<div class="num-with-title">' +
                        '<a class="num ' + item.class + '" href="javascript:;">' +
                        item.number +
                        '</a>' +
                        '<div class="title">' +
                        item.title +
                        '</div>' +
                        '</div>');
                $row.append($item);
            };

        for (var i = 0; i < 4; i++) {
            appendToRow(i, $firstRow);
        }
        for (var i = 4; i < 8; i++) {
            appendToRow(i, $secondRow);
        }
    };

/* Document ready function, after JSON data is loaded */
$("html").bind("JSONLoaded", function () {
    drawMetricTabs();
    initializeCharts();
    initializeActivities();
    initializeMenuItems();
    initializeUserPanel();
    initializeOverviewPanel();
    //set dashboard menu item active
    $($(".main-menu").children()[0]).addClass("active");
    $("h1.title", $("header")).html(theJSON.dashboardTitle);
});


/* Window resizing handler */
$(window).resize(function (event) {
    /* Resize the line chart canvas, redraw the line chart without animation */
    $("#line-chart-canvas").width($(".line-chart-area", $(".content")).width() - 38);
    lineChart.clear();
    drawLineChart(activeTabNum, false);
    
    /* Resize the bar chart canvas, redraw the bar chart without animation */
    $("#bar-chart-canvas").width($(".bar-chart-area", $(".content")).width() - 20);
    barChart.clear();
    drawBarChart(activeTabNum, false);

    /* Resize the scrollable sections*/
    $(".scrollable", $(".accordion-panel.open")).height(window.innerHeight - 29 * 3 - 71).perfectScrollbar("update");
});

/* The JSON object, to be used in the document js */
var theJSON;

$(function () {
    var failureHandler =  function (data) {
            alert("Warning: JSON load failure.");
            console.log(data);
    };
    $.getJSON("js/json/dashboard.json")
        .done(function (data) {
            theJSON = data;
            $.getJSON("js/json/public.json")
                .done(function (publicData) {
                $.extend(theJSON, publicData);
                /* Fire an "JSONLoaded" event, indicating that JSON Object is loaded into the javascript runtime, to be caught by the document js */
                $("html").trigger("JSONLoaded");
            }).fail(failureHandler);
        })
    .fail(failureHandler);
});