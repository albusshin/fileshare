"use strict";

var drawPieChart = function (i) {
        var chartData = theJSON.myMessageFlows.listItems[i].chartData,
            chartOptions = theJSON.myMessageFlows.chartOptions,
            ctx = $("#pie-chart-canvas-" + i).get(0).getContext("2d"),
            pieChart = new Chart(ctx).Doughnut(chartData, chartOptions);
    },
    initializeMessageListItems = function () {
        var listItems = theJSON.myMessageFlows.listItems;
        for (var i in listItems) {
            var listItem = listItems[i],
                percentage = listItem.chartData[0].value / (listItem.chartData[0].value + listItem.chartData[1].value) * 100,
                $listItem = $('<div class="list-item"></div>'),
                $itemContent = $('<div class="item-content"></div>');
            /* Construct the html strings */
            $listItem.append('<div class="icon"></div>');
            $itemContent.append($('<div class="first-row">' +
                '<a class="name" href="message-flow-designer.html">' +
                listItem.name +
                '</a>' +
                '<div class="detail-info">' +
                listItem.detailInfo +
                '</div>' +
                '</div>' +
                '<div class="main-text">' +
                listItem.mainText +
                '</div>' +
                '<div class="last-update-datetime">' +
                'Last Update : ' + listItem.lastUpdateDatetime +
                '</div>' +
                '</div>'));
            $listItem.append($itemContent);
            $listItem.append($('<div class="pie-chart-area">' +
                '<canvas id="pie-chart-canvas-' + i + '" height="63" width="63"></canvas>' +
                '<div class="percentage">' + percentage + '%</div>' +
                '<button class="edit-button">EDIT</button>' +
                '</div>'));

            /* Append the constructed list item to the message flow list */
            $(".message-flow-list").append($listItem);

            /* Draw pie charts */
            drawPieChart(i);
        }
    };

/* Document ready function, after JSON data is loaded */
$("html").bind("JSONLoaded", function () {
    initializeMenuItems();
    initializeUserPanel();
    initializeMessageListItems();
    //set message flows menu item active
    $($(".main-menu").children()[1]).addClass("active");
    $("button.edit-button").click(function() {
        window.location="/message-flow-designer.html";
    });
    $("h1.title", $("header")).html(theJSON.myMessageFlowsTitle);
});

/* The JSON object, to be used in the document js */
var theJSON;

$(function () {
     var failureHandler =  function (data) {
            alert("Warning: JSON load failure.");
            console.log(data);
    };
    $.getJSON("/js/json/my-message-flows.json")
        .done(function (data) {
            theJSON = data;
            $.getJSON("/js/json/public.json")
                .done(function (publicData) {
                $.extend(theJSON, publicData);
                /* Fire an "JSONLoaded" event, indicating that JSON Object is loaded into the javascript runtime, to be caught by the document js */
                $("html").trigger("JSONLoaded");
            }).fail(failureHandler);
        })
    .fail(failureHandler);
});