# Cisco ServiceGrid NextGen - Main Layout UI Prototype Challenge Submission


## File structure:

- *.html : the HTML files
- i/ : the image folder
- css/ : the css folder, contains `css` files compiled by `less` compiler
- css/less/ : the `less` source code, to be compiled to `css` files
- js/ : the javascript folder, contains `js` script files
- js/json/ : the json folder, contains the data in `json` format

## Deployment

In this challenge, JSON files are needed to store the data. So, using `ajax` to load `JSON` is needed.
That means, we need to deploy this UI Prototype on a Web Server. You can use Tomcat, Apache, IIS, whatever web server to run this prototype.
Opening the `html` files directly in the web browser on a file system would cause the `JSON load failure` error, because the `ajax` call cannot be called from the file system.

## Live deployment

If you do not want to set up a web server, please visit [this site](http://albusshin.com/cisco-nextgen-live/dashboard.html) for a live preview of this prototype. 

Only the persons with knowledge of the url above could know about the live preview.

If you want this live preview offline, please send a email to albusshin@gmail.com.